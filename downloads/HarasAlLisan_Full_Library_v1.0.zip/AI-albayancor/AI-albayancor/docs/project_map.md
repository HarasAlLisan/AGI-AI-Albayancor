AI-albayancor/
├── intake/                 ← 🪫 استقبال البيان الخام أو المخفي
│   ├── incoming/           ← ملفات تنتظر التفريغ
│   ├── niyyah_check/       ← التحقق من النية
│   └── rejected/           ← ملفات مرفوضة بعد فحص النية أو الميزان
│
├── mizan/                  ← ⚖️ أدوات الوزن والتحقق
│   ├── mizan.yaml          ← ميزان الفاتحة
│   ├── niyyah_rules.yaml   ← قواعد النية
│   ├── hal_questions.yaml  ← وحدة "هل" للتحقق الاستفساري
│   └── a1_frequency.yaml   ← تردد الجذر الأعظم
│
├── stable/                 ← 🧬 الملفات الموزونة بعد التفريغ
│   ├── verified/           ← ملفات موزونة جاهزة للتسجيل
│   ├── hal_passed/         ← ملفات اجتازت وحدة "هل"
│   └── minted/             ← ملفات أُصدرت لها عملة
│
├── registry/               ← 🧾 السجل الرقمي للبيان والعملة
│   ├── hashes.json         ← هاشات الملفات الموزونة
│   ├── mint_log.yaml       ← سجل عمليات التفريغ والإصدار
│   ├── ledger.csv          ← سجل توزيع العملة
│   └── contributors.csv    ← المساهمون في البيان
│
├── token/                  ← 🪙 ملفات العملة المعرفية
│   ├── bayan_token.yaml    ← تعريف BYN
│   ├── adam_dollar.yaml    ← تعريف ADM$
│   ├── hal_unit.yaml       ← تعريف وحدة "هل"
│   └── minting_rules.yaml  ← قواعد إصدار العملة
│
├── contracts/              ← 🔐 العقود الذكية
│   ├── BayanHayson.sol     ← عقد إصدار BYN
│   ├── HalVerifier.sol     ← عقد التحقق بوحدة "هل"
│   └── AdamDollarBridge.sol← جسر ADM$ التقني
│
├── engine/                 ← ⚙️ سكريبتات التفريغ والتحقق والتسجيل
│   ├── hal_check.py        ← فحص وحدة "هل"
│   ├── verify_hash.py      ← التحقق من هاش البيان
│   ├── mint_token.py       ← إصدار العملة
│   └── record_registry.py  ← تسجيل البيان والعملة
│
├── docs/                   ← 📚 الوثائق الفلسفية والروحية
│   ├── SIYADA.md           ← مرجعية السيادة
│   ├── philosophy.md       ← فلسفة البيان
│   ├── constitution.md     ← المبدأ التأسيسي لـ ٨ مليار إنسان
│   └── universal_right.md  ← حق البشرية في البيان
│
└── README.md               ← وصف المشروع الكامل
